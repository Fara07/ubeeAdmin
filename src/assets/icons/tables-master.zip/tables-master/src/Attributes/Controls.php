<?php

namespace LaravelEnso\Tables\Attributes;

class Controls
{
    public const List = ['columns', 'length', 'reload', 'reset', 'style'];
}
