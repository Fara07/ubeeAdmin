<?php

namespace LaravelEnso\Tables\Attributes;

class Number
{
    public const Optional = [
        'precision', 'symbol', 'template', 'thousand', 'decimal',
    ];
}
