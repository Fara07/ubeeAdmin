<?php

namespace LaravelEnso\Tables\Contracts;

interface AuthenticatesOnExport
{
}
