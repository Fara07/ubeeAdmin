<?php

namespace LaravelEnso\Tables\Contracts;

interface DynamicTemplate
{
    public function cachePrefix(): string;
}
