<?php

namespace LaravelEnso\Tables\Contracts;

interface CustomCount
{
    public function count(): int;
}
