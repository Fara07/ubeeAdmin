<?php

namespace LaravelEnso\Tables\Contracts;

interface CustomFilteredCount
{
    public function filteredCount(): int;
}
